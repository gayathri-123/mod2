package com.dthoperator.ui;
import java.util.Random;

import java.util.Scanner;
import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.service.RechargeCollectionHelper;
import com.dthoperator.service.RechargeDataValidator;
import com.dthoperator.Exception.RechargeException;

public class RechargeClient 
{
	static Scanner cin=new Scanner(System.in);
	public static void main(String[] args) throws RechargeException{
		
       int choice;
       

       while(true)
     {
     	System.out.println("Enter plan of your choice");
     	System.out.println("1----Make a Recharge");
     	System.out.println("2----Add Recharge Details");
     	System.out.println("3----Display Recharge Details");
     	System.out.println("4-----Exit");
     	
     	choice=cin.nextInt();
     	
    	switch(choice)
    	{
    	case 1:
    	{
    		System.out.println("Make a Recharge");
    		RechargeDetails();
    		break;
    	}
    	
    	case 2:
    	{
    		System.out.println("Add Recharge Details");
    		RechargeDetails();
    		break;
    	}
    	
    	case 3:
    	{
    		System.out.println("Display Recharge Details");
    	
    		System.out.println("Enter Transaction ID");
		 	int txn_id=cin.nextInt();
		 	RechargeCollectionHelper.displayRechargeDetails(txn_id);
    		break;
    	}
    	case 4:
    	{
    		System.exit(0);
    		break;
		}
	
    	default:
    	{
		System.out.println("Enter proper option");
		break;
    	}

    	}
     }
}


private static void RechargeDetails() 
{
		// TODO Auto-generated method stub
		
	}


public static void Make_Recharge() throws RechargeException{
	System.out.println("Enter Recharge Details to be Added for house TV");
	//System.out.println("Add RechargeDetails")
	int RechargeDetails;
	RechargeDetails=cin.nextInt();

	while(RechargeDetails!=0)
	{
		
		System.out.println("Select DTH Operator (Airtel / DishTV / Reliance / TATASky");
		String dth_operator=cin.next();
		try {
		if(!RechargeDataValidator.validatedth(dth_operator)) 
		{
			System.exit(0);
		}
		
		System.out.println("Enter Registered Consumer No.");
		String consumer_id=cin.next();
		if(!RechargeDataValidator.validateConsumerNo(consumer_id)) 
		{
			System.exit(0);
		}
		
		System.out.println("Select Plan(Monthly / Quaterly / Half yearly / Annual)");
		String consumer_plan=cin.next();

		if(!RechargeDataValidator.validateRechargePlan(consumer_plan)) 
		{
			System.exit(0);
		}
		
		System.out.println("Enter Amount (Rs.)");
		String recharge_amount=cin.next();

		if(!RechargeDataValidator.validateAmount(recharge_amount)) 
		{
			System.exit(0);
		}

		

		//double c_id=Double.parseDouble(consumer_id);
		int amt=Integer.parseInt(recharge_amount);
		Random random = new Random();
		int transaction_id = random.nextInt(1000);
		int id=Integer.parseInt(consumer_id);
		RechargeDetails obj=new RechargeDetails(dth_operator,id,consumer_plan,amt,transaction_id);
		RechargeCollectionHelper.addRechargeDetails(obj);
		System.out.println("Successful Recharge. Transaction ID:" +transaction_id);
		}
		
		catch(RechargeException e)
		{
			
			
		}
		RechargeDetails--;
		if(RechargeDetails==1)
		System.out.println("Enter the Recharge Details for Office DTH");
		
	}	
	
	}

}



    	


