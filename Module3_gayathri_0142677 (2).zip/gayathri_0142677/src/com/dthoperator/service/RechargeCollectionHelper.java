package com.dthoperator.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dthoperator.bean.RechargeDetails;
public class RechargeCollectionHelper {
	
	static List<RechargeDetails> list = new ArrayList<RechargeDetails>();
	static{
		
		RechargeDetails recharge1 = new RechargeDetails("Airtel",10832140,"Monthly",210,4567);
		list.add(recharge1);
		RechargeDetails recharge2 = new RechargeDetails("DishTV",3037419,"Yearly",1260,2345);
		list.add(recharge2);
		RechargeDetails recharge3 = new RechargeDetails("Reliance",8987413,"Quaterly",650,1234);
		list.add(recharge3);
	}


	public static void addRechargeDetails(RechargeDetails rechargeDetails)
	{
		list.add(rechargeDetails);
	}

	public static void displayRechargeDetails(int transactionID1)
	{
		for(Object object: list)
		{
			RechargeDetails obj=(RechargeDetails)object;
			if(obj.transactionID==transactionID1)
			{
				System.out.println(object);
			}
		}
	}

}
