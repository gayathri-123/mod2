package com.dthoperator.service;

import java.util.regex.Pattern;

import com.dthoperator.Exception.RechargeException;

public class RechargeDataValidator 
{
	public static boolean validatedth(String dth) throws RechargeException
	{
		if(dth.toLowerCase().equals("airtel")||dth.toLowerCase().equals("dishtv")||dth.toLowerCase().equals("reliance")||dth.toLowerCase().equals("tatasky"))
		{
			return true;
		}
		else 
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validateConsumerNo(String consumerNo) throws RechargeException
	{
		String pattern = "[0-9]{10}";
		if(Pattern.matches(pattern,consumerNo))
		{
			return true;
		}
		else
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validateRechargePlan(String Rechargeplan) throws RechargeException
	{
		if(Rechargeplan.toLowerCase().equals("monthly")||Rechargeplan.toLowerCase().equals("quaterly")||Rechargeplan.toLowerCase().equals("half yearly")||Rechargeplan.toLowerCase().equals("annual"))
		{
			return true;
		}
		else 
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validateAmount(String amount) throws RechargeException
	{
		String pattern = "[1-9]{1}[0-9]{3,4}";
		if(Pattern.matches(pattern,amount))
		{
			return true;
		}
		else
		{
			throw new RechargeException("A");
			//return false;
		}
	}

}
