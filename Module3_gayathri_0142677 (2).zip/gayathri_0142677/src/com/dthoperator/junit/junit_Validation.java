package com.dthoperator.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.dthoperator.Exception.RechargeException;
import com.dthoperator.service.RechargeDataValidator;

public class junit_Validation {
	
	@Test
	public void test_dthOperator() throws RechargeException {
		Assert.assertEquals(true,RechargeDataValidator.validatedth("Reliance"));

	}
	
	@Test
	public void test_ConsumerNumber() throws RechargeException {
		Assert.assertEquals(true,RechargeDataValidator.validateConsumerNo("8923434300"));

	}
	
	@Test
	public void test_RechargePlan() throws RechargeException {
		Assert.assertEquals(true,RechargeDataValidator.validateRechargePlan("Quaterly"));

	}

	@Test
	public void test_RechargeAmount() throws RechargeException {
		Assert.assertEquals(true,RechargeDataValidator.validateAmount("895"));

	}

}
