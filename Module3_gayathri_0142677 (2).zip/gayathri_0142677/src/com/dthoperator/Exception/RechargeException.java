package com.dthoperator.Exception;

public class RechargeException extends Exception {
	
	public RechargeException(String name)
	{
		System.out.println("Failed to Recharge.");
		return;
	}

}
