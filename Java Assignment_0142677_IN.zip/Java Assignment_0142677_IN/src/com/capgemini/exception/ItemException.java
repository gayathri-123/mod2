package com.capgemini.exception;

public class ItemException extends Exception{

	
	private static final long serialVersionUID = 1L;


	public ItemException(int id)
	{
		System.out.println("Entered ID is Invalid");
		return  ;

	}

	public ItemException(double price)
	{
		System.out.println("Entered Price is Invalid");
		return;
	}
	
	
	public ItemException(String name)
	{
		System.out.println("Item Name entered is Invalid");
		return;
	}
}
