package com.cg.ui;

import com.capgemini.bin.*;

import java.util.*;

import com.capgemini.exception.*;
import com.capgemini.collection.*;
import com.capgemini.validator.*;


public class ItemUI {
	static Scanner cin=new Scanner(System.in);
	public static void main(String[] args) throws ItemException{
		
       int choice;

  while(true)
{
	System.out.println("Enter your choice");
	System.out.println("1----Add Details");
	System.out.println("2----Count Records");
	System.out.println("3---- Display Records");
	System.out.println("4---- find duplicate");
	System.out.println("5---- remove Records");
	System.out.println("6----Exit");
	
	choice=cin.nextInt();
	switch(choice)
	{
	case 1:{
		System.out.println("Add Details");
		EXP();
		break;}
	
	case 2:{System.out.println("Count Records");
		Collector.count_records();
		break;}
	
	case 3:{
		{System.out.println("Display Records");
		
		Collector.displayrec();
		break;}
		}
	
	case 4:{System.out.println("Find duplicate");
		System.out.println("Enter ID to Find Specific Record by ID");
		int get_id=cin.nextInt();
		Collector.duplication(getid);
		break;}
	
	case 5:{System.out.println("Remove Records");
		System.out.println("Enter ID to Remove Specific Record by ID");
		int getid=cin.nextInt();
		Collector.removebyid(getid);
		break;}
	
	case 6:{System.exit(0);
		break;}
	
	default:{System.out.println("Enter proper option");
		break;}
	}
}
	}
	public static void EXP() throws ItemException{
		System.out.println("Enter Number of Items to be Added");
		int NumItems;
		Num_Items=cin.nextInt();
		while(NumItems!=0)
		{
			
			System.out.println("Enter Item ID");
			int itemid=cin.nextInt();
			try {
			if(!Validator.validateid(itemid)) 
			{
				System.exit(0);
			}
			System.out.println("Enter Item Name");
			String itemname=cin.next();
			if(!Validator.validatename(itemname))
			{
				System.exit(0);
			}
			System.out.println("Enter Item Price");
			double itemprice=cin.nextDouble();
			if(!Validator.validateprice(itemprice))
			{
				System.exit(0);
			}
			
			Random randomGenerator = new Random();
			int txnid = randomGenerator.nextInt(9999);
			
			ItemSchema sch=new ItemSchema(itemid,itemname,itemprice,txnid);
			Collector.adddetails(sch);
			}
			catch(ItemException e)
			{
				
				
			}
			NumItems--;
		}	
		
	}
	
}