/********************************************************************************
	File 			: common.js
	 Author Name		: Rushabh Mehta 
	Employee ID 		: 137585
	Description 		: Using Variable in many Script tags(common.js)
 	Version 		: 1.0
	Last modified date 	: 05/10/2017
 	Change Description	: NA
	
*********************************************************************************/

function addnos(headvar,bodyvar)
{
	document.write("The sum of the variables headVar and bodyVar is"+(headvar+bodyvar));	
}