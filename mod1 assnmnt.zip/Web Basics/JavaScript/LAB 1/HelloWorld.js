<!--/********************************************************************************
	File 			: HelloWorld.js
	 Author Name		: Rushabh Mehta 
	Employee ID 		: 137585
	Description 		: Create page to show use of external JavaScript
 	Version 		: 1.0
	Last modified date 	: 05/10/2017
 	Change Description	: NA
	
*********************************************************************************/-->

function helloworld()
{
	document.write("Hello World!!")	 
}

